const mongoose = require("mongoose");

const connect = () => {
  return mongoose.connect(
    " "
  );
};

module.exports = connect;