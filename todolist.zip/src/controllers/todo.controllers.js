const express = require("express");

const User = require("src/models/todo.models.js");

const crudController = require("src/controllers/crud.controllers.js");

const router = express.Router();

router.get("", async (req, res) => {
  try {
    const users = await User.find().lean().exec();

    return res.status(200).send({ users: users }); 
  } catch (err) {
    return res.status(500).send({ message: err.message });
  }
});