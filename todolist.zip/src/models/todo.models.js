const mongoose = require("mongoose");


const todoSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    createdAt:{ type: String, required: true},
    updateAt:{type:String, required: true}
  },
  {
    versionKey: false,
    timestamps: true, 
  }
);


const User = mongoose.model("todo", todoSchema); 

module.exports = todo;
